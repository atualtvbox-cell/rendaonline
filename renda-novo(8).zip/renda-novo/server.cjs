const express = require("express");
const Database = require("better-sqlite3");
const cors = require("cors");
const path = require("path");

const db = new Database(path.join(__dirname, "renda.db"));
db.pragma("journal_mode = WAL");

db.exec("CREATE TABLE IF NOT EXISTS transacoes (id INTEGER PRIMARY KEY AUTOINCREMENT, descricao TEXT NOT NULL, valor REAL NOT NULL, tipo TEXT NOT NULL, categoria TEXT NOT NULL, recorrencia TEXT NOT NULL, data TEXT NOT NULL, pago INTEGER NOT NULL DEFAULT 1, criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)");
db.exec("CREATE TABLE IF NOT EXISTS empresa (id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT NOT NULL, descricao TEXT NOT NULL, contraparte TEXT, valor REAL NOT NULL, data TEXT NOT NULL, criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)");
db.exec("CREATE TABLE IF NOT EXISTS configuracoes (chave TEXT PRIMARY KEY, valor TEXT)");
db.exec("CREATE TABLE IF NOT EXISTS categorias (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE)");
db.exec("CREATE TABLE IF NOT EXISTS contas_bancarias (id INTEGER PRIMARY KEY AUTOINCREMENT, banco TEXT NOT NULL, agencia TEXT NOT NULL, conta TEXT NOT NULL, tipo TEXT DEFAULT 'corrente', titular TEXT, ativa INTEGER DEFAULT 1)");

db.exec("CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, senha TEXT NOT NULL, criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)");

var userCount = db.prepare("SELECT COUNT(*) as total FROM usuarios").get();
if (userCount.total === 0) {
  db.prepare("INSERT INTO usuarios (nome, senha) VALUES (?, ?)").run("admin", "1234");
}

var catCount = db.prepare("SELECT COUNT(*) as total FROM categorias").get();
if (catCount.total === 0) {
  var cats = ["Alimentacao","Transporte","Moradia","Saude","Educacao","Lazer","Vestuario","Salario","Freelance","Investimentos","Outros"];
  var insertCat = db.prepare("INSERT OR IGNORE INTO categorias (nome) VALUES (?)");
  for (var i = 0; i < cats.length; i++) { insertCat.run(cats[i]); }
}

var app = express();
app.use(cors());
app.use(express.json());

app.get("/api/transacoes", function(req, res) { res.json(db.prepare("SELECT * FROM transacoes ORDER BY data DESC").all()); });
app.post("/api/transacoes", function(req, res) { var b = req.body; var r = db.prepare("INSERT INTO transacoes (descricao,valor,tipo,categoria,recorrencia,data,pago) VALUES (?,?,?,?,?,?,?)").run(b.descricao,b.valor,b.tipo,b.categoria,b.recorrencia,b.data,b.pago?1:0); res.json({id:r.lastInsertRowid, descricao:b.descricao, valor:b.valor, tipo:b.tipo, categoria:b.categoria, recorrencia:b.recorrencia, data:b.data, pago:b.pago?1:0}); });
app.delete("/api/transacoes/:id", function(req, res) { db.prepare("DELETE FROM transacoes WHERE id=?").run(req.params.id); res.json({ok:true}); });
app.patch("/api/transacoes/:id/pago", function(req, res) { db.prepare("UPDATE transacoes SET pago = CASE WHEN pago=1 THEN 0 ELSE 1 END WHERE id=?").run(req.params.id); res.json({ok:true}); });

app.get("/api/empresa", function(req, res) { res.json(db.prepare("SELECT * FROM empresa ORDER BY data DESC").all()); });
app.post("/api/empresa", function(req, res) { var b = req.body; var r = db.prepare("INSERT INTO empresa (tipo,descricao,contraparte,valor,data) VALUES (?,?,?,?,?)").run(b.tipo,b.descricao,b.contraparte,b.valor,b.data); res.json({id:r.lastInsertRowid, tipo:b.tipo, descricao:b.descricao, contraparte:b.contraparte, valor:b.valor, data:b.data}); });
app.delete("/api/empresa/:id", function(req, res) { db.prepare("DELETE FROM empresa WHERE id=?").run(req.params.id); res.json({ok:true}); });

app.get("/api/categorias", function(req, res) { res.json(db.prepare("SELECT * FROM categorias ORDER BY nome").all()); });
app.post("/api/categorias", function(req, res) { try { var r = db.prepare("INSERT INTO categorias (nome) VALUES (?)").run(req.body.nome); res.json({id:r.lastInsertRowid, nome:req.body.nome}); } catch(e) { res.status(400).json({erro:"Categoria ja existe"}); } });
app.delete("/api/categorias/:id", function(req, res) { db.prepare("DELETE FROM categorias WHERE id=?").run(req.params.id); res.json({ok:true}); });

app.get("/api/contas", function(req, res) { res.json(db.prepare("SELECT * FROM contas_bancarias ORDER BY banco").all()); });
app.post("/api/contas", function(req, res) { var b = req.body; var r = db.prepare("INSERT INTO contas_bancarias (banco,agencia,conta,tipo,titular) VALUES (?,?,?,?,?)").run(b.banco,b.agencia,b.conta,b.tipo||"corrente",b.titular||""); res.json({id:r.lastInsertRowid, banco:b.banco, agencia:b.agencia, conta:b.conta, tipo:b.tipo||"corrente", titular:b.titular||""}); });
app.put("/api/contas/:id", function(req, res) { var b = req.body; db.prepare("UPDATE contas_bancarias SET banco=?,agencia=?,conta=?,tipo=?,titular=? WHERE id=?").run(b.banco,b.agencia,b.conta,b.tipo,b.titular,req.params.id); res.json({ok:true}); });
app.delete("/api/contas/:id", function(req, res) { db.prepare("DELETE FROM contas_bancarias WHERE id=?").run(req.params.id); res.json({ok:true}); });

app.post("/api/login", function(req, res) { var b = req.body; var u = db.prepare("SELECT * FROM usuarios WHERE nome=? AND senha=?").get(b.nome, b.senha); if (u) { res.json({ok:true, id:u.id, nome:u.nome}); } else { res.status(401).json({ok:false, erro:"Usuario ou senha incorretos"}); } });

app.put("/api/usuario/:id", function(req, res) { var b = req.body; if (!b.nome || !b.senha) return res.status(400).json({erro:"Nome e senha obrigatorios"}); db.prepare("UPDATE usuarios SET nome=?, senha=? WHERE id=?").run(b.nome, b.senha, req.params.id); res.json({ok:true, id:Number(req.params.id), nome:b.nome}); });

app.get("/api/exportar", function(req, res) { res.json({ transacoes: db.prepare("SELECT * FROM transacoes").all(), empresa: db.prepare("SELECT * FROM empresa").all(), categorias: db.prepare("SELECT * FROM categorias").all(), contas: db.prepare("SELECT * FROM contas_bancarias").all() }); });
app.post("/api/importar", function(req, res) { var d = req.body; if(d.transacoes) { db.exec("DELETE FROM transacoes"); var st = db.prepare("INSERT INTO transacoes (descricao,valor,tipo,categoria,recorrencia,data,pago) VALUES (?,?,?,?,?,?,?)"); d.transacoes.forEach(function(t) { st.run(t.descricao,t.valor,t.tipo,t.categoria,t.recorrencia,t.data,t.pago?1:0); }); } if(d.empresa) { db.exec("DELETE FROM empresa"); var se = db.prepare("INSERT INTO empresa (tipo,descricao,contraparte,valor,data) VALUES (?,?,?,?,?)"); d.empresa.forEach(function(e) { se.run(e.tipo,e.descricao,e.contraparte,e.valor,e.data); }); } res.json({ok:true}); });

app.listen(3001, function() {
  console.log("========================================");
  console.log("  RENDA - Servidor do banco de dados");
  console.log("========================================");
  console.log("  Banco: renda.db");
  console.log("  API:   http://localhost:3001/api");
  console.log("  Nao feche esta janela!");
  console.log("========================================");
});
