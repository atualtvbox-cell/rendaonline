import { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import Painel from "./pages/Painel";
import Transacoes from "./pages/Transacoes";
import Relatorios from "./pages/Relatorios";
import Empresa from "./pages/Empresa";
import Configuracoes from "./pages/Configuracoes";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";

export function App() {
  var [usuario, setUsuario] = useState(null);

  useEffect(function() {
    var salvo = localStorage.getItem("renda:usuario");
    if (salvo) {
      try { setUsuario(JSON.parse(salvo)); } catch(e) {}
    }
  }, []);

  if (!usuario) {
    return <Login onLogin={function(u) { setUsuario(u); }} />;
  }

  return (
    <Routes>
      <Route path="/" element={<Painel />} />
      <Route path="/transacoes" element={<Transacoes />} />
      <Route path="/relatorios" element={<Relatorios />} />
      <Route path="/empresa" element={<Empresa />} />
      <Route path="/configuracoes" element={<Configuracoes />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
