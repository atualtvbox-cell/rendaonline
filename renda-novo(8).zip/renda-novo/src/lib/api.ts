function getApiUrl() {
  if (typeof window !== "undefined" && window.location.hostname !== "localhost") {
    return window.location.origin.replace("-5173.", "-3001.") + "/api";
  }
  return "http://localhost:3001/api";
}

var API = getApiUrl();

export async function listarTransacoes() { var res = await fetch(API + "/transacoes"); return res.json(); }
export async function criarTransacao(t) { var res = await fetch(API + "/transacoes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(t) }); return res.json(); }
export async function removerTransacao(id) { await fetch(API + "/transacoes/" + id, { method: "DELETE" }); }
export async function alternarPago(id) { await fetch(API + "/transacoes/" + id + "/pago", { method: "PATCH" }); }

export async function listarEmpresa() { var res = await fetch(API + "/empresa"); return res.json(); }
export async function criarLancamentoEmpresa(l) { var res = await fetch(API + "/empresa", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(l) }); return res.json(); }
export async function removerLancamentoEmpresa(id) { await fetch(API + "/empresa/" + id, { method: "DELETE" }); }

export async function listarCategorias() { var res = await fetch(API + "/categorias"); return res.json(); }
export async function criarCategoria(nome) { var res = await fetch(API + "/categorias", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nome: nome }) }); return res.json(); }
export async function removerCategoria(id) { await fetch(API + "/categorias/" + id, { method: "DELETE" }); }

export async function listarContas() { var res = await fetch(API + "/contas"); return res.json(); }
export async function criarConta(c) { var res = await fetch(API + "/contas", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(c) }); return res.json(); }
export async function atualizarConta(id, c) { var res = await fetch(API + "/contas/" + id, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(c) }); return res.json(); }
export async function removerConta(id) { await fetch(API + "/contas/" + id, { method: "DELETE" }); }

export async function exportarDados() { var res = await fetch(API + "/exportar"); var dados = await res.json(); var blob = new Blob([JSON.stringify(dados, null, 2)], { type: "application/json" }); var url = URL.createObjectURL(blob); var a = document.createElement("a"); a.href = url; a.download = "renda-backup-" + new Date().toISOString().slice(0, 10) + ".json"; a.click(); URL.revokeObjectURL(url); }
export async function importarDados(arquivo) { var texto = await arquivo.text(); var dados = JSON.parse(texto); var res = await fetch(API + "/importar", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(dados) }); return res.json(); }

export async function login(nome, senha) { var res = await fetch(API + "/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nome: nome, senha: senha }) }); return res.json(); }
export async function registrar(nome, senha) { var res = await fetch(API + "/registrar", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nome: nome, senha: senha }) }); return res.json(); }
export async function atualizarUsuario(id, nome, senha) { var res = await fetch(API + "/usuario/" + id, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nome: nome, senha: senha }) }); return res.json(); }
