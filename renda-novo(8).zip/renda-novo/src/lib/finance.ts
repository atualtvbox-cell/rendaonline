import { useCallback, useEffect, useState } from "react";
import * as api from "./api";

export type TipoTransacao = "receita" | "despesa";
export type Recorrencia = "fixa" | "variavel";
export type TipoEmpresa = "compra" | "venda" | "entrada";
export type Periodo = "dia" | "semana" | "mes";

export interface Transacao {
  id: number; descricao: string; valor: number; tipo: TipoTransacao;
  categoria: string; recorrencia: Recorrencia; data: string; pago: boolean;
}

export interface LancamentoEmpresa {
  id: number; tipo: TipoEmpresa; descricao: string;
  contraparte: string; valor: number; data: string;
}

export const CATEGORIAS = [
  "Alimentação","Moradia","Transporte","Saúde","Educação","Lazer",
  "Vestuário","Serviços","Impostos","Investimentos","Salário","Freelance","Outros",
];

export const CORES_CATEGORIA: Record<string, string> = {
  "Alimentação":"var(--color-chart-1)","Moradia":"var(--color-chart-2)",
  "Transporte":"var(--color-chart-3)","Saúde":"var(--color-chart-4)",
  "Educação":"var(--color-chart-5)","Lazer":"var(--color-positive)",
  "Vestuário":"var(--color-warning)","Serviços":"var(--color-negative)",
  "Impostos":"var(--color-muted-foreground)","Investimentos":"var(--color-primary)",
  "Salário":"var(--color-positive)","Freelance":"var(--color-chart-1)",
  "Outros":"var(--color-chart-4)",
};

export const ROTULO_EMPRESA: Record<TipoEmpresa, string> = {
  compra: "Compra", venda: "Venda", entrada: "Entrada",
};

export function useFinancas() {
  const [transacoes, setTransacoes] = useState<Transacao[]>([]);
  const [empresa, setEmpresa] = useState<LancamentoEmpresa[]>([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    Promise.all([api.listarTransacoes(), api.listarEmpresa()])
      .then(([t, e]) => { setTransacoes(t); setEmpresa(e); })
      .catch((err) => console.error("Erro ao carregar dados:", err))
      .finally(() => setCarregando(false));
  }, []);

  const adicionarTransacao = useCallback(async (t: Omit<Transacao, "id">) => {
    const nova = await api.criarTransacao(t);
    setTransacoes((prev) => [nova, ...prev]);
  }, []);

  const removerTransacao = useCallback(async (id: number) => {
    await api.removerTransacao(id);
    setTransacoes((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const alternarPago = useCallback(async (id: number) => {
    await api.alternarPago(id);
    setTransacoes((prev) => prev.map((t) => (t.id === id ? { ...t, pago: !t.pago } : t)));
  }, []);

  const adicionarLancamentoEmpresa = useCallback(async (l: Omit<LancamentoEmpresa, "id">) => {
    const novo = await api.criarLancamentoEmpresa(l);
    setEmpresa((prev) => [novo, ...prev]);
  }, []);

  const removerLancamentoEmpresa = useCallback(async (id: number) => {
    await api.removerLancamentoEmpresa(id);
    setEmpresa((prev) => prev.filter((l) => l.id !== id));
  }, []);

  return { transacoes, empresa, carregando, adicionarTransacao, removerTransacao, alternarPago, adicionarLancamentoEmpresa, removerLancamentoEmpresa };
}

export function brl(v: any) { if (v == null) return "R$ 0,00"; return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }); }

export function formatarData(iso: string) { const [y, m, d] = iso.split("-"); return `${d}/${m}/${y}`; }

export function mesAtual() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function diasAte(iso: string) {
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const alvo = new Date(iso + "T00:00:00");
  return Math.round((alvo.getTime() - hoje.getTime()) / 86400000);
}

export function resumoMes(transacoes: Transacao[], mes: string) {
  const do_mes = transacoes.filter((t) => t.data.startsWith(mes));
  const receitas = do_mes.filter((t) => t.tipo === "receita").reduce((s, t) => s + t.valor, 0);
  const despesas = do_mes.filter((t) => t.tipo === "despesa").reduce((s, t) => s + t.valor, 0);
  return { receitas, despesas, saldo: receitas - despesas, transacoes: do_mes };
}

export function saldoAcumulado(transacoes: Transacao[]) {
  return transacoes.reduce((s, t) => s + (t.tipo === "receita" ? t.valor : -t.valor), 0);
}

export function contasAVencer(transacoes: Transacao[]) {
  return transacoes.filter((t) => !t.pago && t.tipo === "despesa").sort((a, b) => a.data.localeCompare(b.data)).slice(0, 5);
}

export function serieMensal(transacoes: Transacao[], meses = 6) {
  const hoje = new Date(); const serie = [];
  for (let i = meses - 1; i >= 0; i--) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth() - i, 1);
    const chave = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const rotulo = d.toLocaleDateString("pt-BR", { month: "short" }).replace(".", "");
    const do_mes = transacoes.filter((t) => t.data.startsWith(chave));
    const receitas = do_mes.filter((t) => t.tipo === "receita").reduce((s, t) => s + t.valor, 0);
    const despesas = do_mes.filter((t) => t.tipo === "despesa").reduce((s, t) => s + t.valor, 0);
    serie.push({ chave, rotulo, receitas, despesas });
  }
  return serie;
}

export function porCategoria(transacoes: Transacao[], mes: string) {
  const do_mes = transacoes.filter((t) => t.data.startsWith(mes) && t.tipo === "despesa");
  const mapa: Record<string, number> = {};
  for (const t of do_mes) mapa[t.categoria] = (mapa[t.categoria] || 0) + t.valor;
  return Object.entries(mapa).map(([categoria, valor]) => ({ categoria, valor })).sort((a, b) => b.valor - a.valor);
}

export function chavePeriodo(iso: string, periodo: Periodo) {
  const d = new Date(iso + "T00:00:00");
  if (periodo === "dia") return iso;
  if (periodo === "semana") { const inicio = new Date(d); inicio.setDate(d.getDate() - d.getDay()); return inicio.toISOString().slice(0, 10); }
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function rotuloChave(chave: string, periodo: Periodo) {
  if (periodo === "dia") { const [, m, d] = chave.split("-"); return `${d}/${m}`; }
  if (periodo === "semana") { const [, m, d] = chave.split("-"); return `Sem ${d}/${m}`; }
  const [y, m] = chave.split("-");
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString("pt-BR", { month: "short", year: "2-digit" }).replace(".", "");
}

export function relatorioTransacoes(transacoes: Transacao[], periodo: Periodo, limite = 6) {
  const mapa: Record<string, { receitas: number; despesas: number; descricoes: string[] }> = {};
  for (const t of transacoes) {
    const chave = chavePeriodo(t.data, periodo);
    if (!mapa[chave]) mapa[chave] = { receitas: 0, despesas: 0, descricoes: [] };
    if (t.tipo === "receita") mapa[chave].receitas += t.valor; else mapa[chave].despesas += t.valor;
    mapa[chave].descricoes.push(t.descricao);
  }
  return Object.entries(mapa).map(([chave, v]) => ({
    chave, rotulo: rotuloChave(chave, periodo), receitas: v.receitas, despesas: v.despesas,
    saldo: v.receitas - v.despesas, descricao: v.descricoes.slice(0, 3).join(", "),
  })).sort((a, b) => a.chave.localeCompare(b.chave)).slice(-limite);
}

export function totaisEmpresa(lancamentos: LancamentoEmpresa[]) {
  let vendas = 0, compras = 0, entradas = 0;
  for (const l of lancamentos) { if (l.tipo === "venda") vendas += l.valor; else if (l.tipo === "compra") compras += l.valor; else entradas += l.valor; }
  return { vendas, compras, entradas, resultado: vendas + entradas - compras };
}

export function relatorioEmpresa(lancamentos: LancamentoEmpresa[], periodo: Periodo, limite = 12) {
  const mapa: Record<string, { vendas: number; compras: number; entradas: number }> = {};
  for (const l of lancamentos) {
    const chave = chavePeriodo(l.data, periodo);
    if (!mapa[chave]) mapa[chave] = { vendas: 0, compras: 0, entradas: 0 };
    if (l.tipo === "venda") mapa[chave].vendas += l.valor; else if (l.tipo === "compra") mapa[chave].compras += l.valor; else mapa[chave].entradas += l.valor;
  }
  return Object.entries(mapa).map(([chave, v]) => ({
    chave, rotulo: rotuloChave(chave, periodo), vendas: v.vendas, compras: v.compras,
    entradas: v.entradas, resultado: v.vendas + v.entradas - v.compras,
  })).sort((a, b) => a.chave.localeCompare(b.chave)).slice(-limite);
}
