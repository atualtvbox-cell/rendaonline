import { useCallback, useEffect, useSyncExternalStore } from "react";

export type TipoTransacao = "receita" | "despesa";
export type Recorrencia = "fixa" | "variavel";

export interface Transacao {
  id: string;
  descricao: string;
  valor: number;
  tipo: TipoTransacao;
  recorrencia: Recorrencia;
  categoria: string;
  data: string; // ISO yyyy-mm-dd
  pago: boolean;
}

export interface Orcamento {
  id: string;
  categoria: string;
  limite: number;
}

export interface Meta {
  id: string;
  nome: string;
  alvo: number;
  guardado: number;
  prazo: string; // yyyy-mm-dd
}

export type TipoEmpresa = "compra" | "venda" | "entrada";

export interface LancamentoEmpresa {
  id: string;
  tipo: TipoEmpresa;
  descricao: string;
  contraparte: string;
  valor: number;
  data: string; // yyyy-mm-dd
}

export const ROTULO_EMPRESA: Record<TipoEmpresa, string> = {
  compra: "Compra",
  venda: "Venda",
  entrada: "Entrada de recursos",
};

export interface Estado {
  transacoes: Transacao[];
  orcamentos: Orcamento[];
  metas: Meta[];
  empresa: LancamentoEmpresa[];
}

export const CATEGORIAS = [
  "Moradia",
  "Alimentação",
  "Transporte",
  "Saúde",
  "Educação",
  "Lazer",
  "Assinaturas",
  "Salário",
  "Investimentos",
  "Outros",
] as const;

export const CORES_CATEGORIA: Record<string, string> = {
  Moradia: "var(--color-chart-4)",
  Alimentação: "var(--color-chart-3)",
  Transporte: "var(--color-chart-6)",
  Saúde: "var(--color-chart-2)",
  Educação: "var(--color-chart-5)",
  Lazer: "var(--color-chart-5)",
  Assinaturas: "var(--color-chart-4)",
  Salário: "var(--color-chart-1)",
  Investimentos: "var(--color-chart-1)",
  Outros: "var(--color-muted-foreground)",
};

const CHAVE = "renda:estado:v1";

function iso(ano: number, mes: number, dia: number) {
  return `${ano}-${String(mes + 1).padStart(2, "0")}-${String(dia).padStart(2, "0")}`;
}

function estadoInicial(): Estado {
  const hoje = new Date();
  const a = hoje.getFullYear();
  const m = hoje.getMonth();
  const mesAnterior = m === 0 ? 11 : m - 1;
  const anoAnterior = m === 0 ? a - 1 : a;

  const t = (
    descricao: string,
    valor: number,
    tipo: TipoTransacao,
    recorrencia: Recorrencia,
    categoria: string,
    data: string,
    pago = true,
  ): Transacao => ({
    id: crypto.randomUUID(),
    descricao,
    valor,
    tipo,
    recorrencia,
    categoria,
    data,
    pago,
  });

  return {
    transacoes: [
      t("Salário", 9200, "receita", "fixa", "Salário", iso(a, m, 5)),
      t("Freelance de design", 1450, "receita", "variavel", "Outros", iso(a, m, 12)),
      t("Aluguel", 2350, "despesa", "fixa", "Moradia", iso(a, m, 5)),
      t("Supermercado", 812.4, "despesa", "variavel", "Alimentação", iso(a, m, 9)),
      t("Plano de saúde", 480, "despesa", "fixa", "Saúde", iso(a, m, 10)),
      t("Streaming", 59.9, "despesa", "fixa", "Assinaturas", iso(a, m, 3)),
      t("Combustível", 320, "despesa", "variavel", "Transporte", iso(a, m, 11)),
      t("Restaurantes", 415.6, "despesa", "variavel", "Alimentação", iso(a, m, 14)),
      t("Cinema e shows", 190, "despesa", "variavel", "Lazer", iso(a, m, 15)),
      t("Energia elétrica", 214.8, "despesa", "fixa", "Moradia", iso(a, m, 22), false),
      t("Fatura do cartão", 1420, "despesa", "variavel", "Outros", iso(a, m, 25), false),
      t("Internet fibra", 119, "despesa", "fixa", "Moradia", iso(a, m, 28), false),
      t("Salário", 9200, "receita", "fixa", "Salário", iso(anoAnterior, mesAnterior, 5)),
      t("Aluguel", 2350, "despesa", "fixa", "Moradia", iso(anoAnterior, mesAnterior, 5)),
      t("Supermercado", 905, "despesa", "variavel", "Alimentação", iso(anoAnterior, mesAnterior, 8)),
      t("Transporte", 410, "despesa", "variavel", "Transporte", iso(anoAnterior, mesAnterior, 16)),
      t("Lazer", 380, "despesa", "variavel", "Lazer", iso(anoAnterior, mesAnterior, 20)),
    ],
    orcamentos: [
      { id: crypto.randomUUID(), categoria: "Moradia", limite: 3000 },
      { id: crypto.randomUUID(), categoria: "Alimentação", limite: 1400 },
      { id: crypto.randomUUID(), categoria: "Transporte", limite: 600 },
      { id: crypto.randomUUID(), categoria: "Lazer", limite: 400 },
      { id: crypto.randomUUID(), categoria: "Saúde", limite: 600 },
    ],
    metas: [
      {
        id: crypto.randomUUID(),
        nome: "Reserva de emergência",
        alvo: 30000,
        guardado: 18600,
        prazo: iso(a + 1, 5, 30),
      },
      {
        id: crypto.randomUUID(),
        nome: "Viagem em família",
        alvo: 15000,
        guardado: 5100,
        prazo: iso(a + 1, 0, 15),
      },
      {
        id: crypto.randomUUID(),
        nome: "Entrada do imóvel",
        alvo: 80000,
        guardado: 14400,
        prazo: iso(a + 3, 11, 20),
      },
    ],
    empresa: empresaInicial(),
  };
}

function empresaInicial(): LancamentoEmpresa[] {
  const hoje = new Date();
  const dia = (n: number) => {
    const d = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - n);
    return iso(d.getFullYear(), d.getMonth(), d.getDate());
  };
  const e = (
    tipo: TipoEmpresa,
    descricao: string,
    contraparte: string,
    valor: number,
    d: number,
  ): LancamentoEmpresa => ({
    id: crypto.randomUUID(),
    tipo,
    descricao,
    contraparte,
    valor,
    data: dia(d),
  });
  return [
    e("venda", "Venda balcão", "Cliente avulso", 1280.5, 0),
    e("compra", "Reposição de estoque", "Distribuidora Sul", 2340, 1),
    e("entrada", "Recebimento em dinheiro", "Caixa", 860, 1),
    e("venda", "Pedido nº 1042", "Mercado Vila Nova", 3420, 3),
    e("compra", "Embalagens", "Pack Brasil", 480.9, 5),
    e("entrada", "Aporte do sócio", "Sócio", 5000, 8),
    e("venda", "Pedido nº 1039", "Padaria Central", 2190, 10),
    e("compra", "Energia e água", "Concessionária", 735.2, 14),
    e("venda", "Pedido nº 1031", "Restaurante Bom Prato", 4780, 20),
    e("entrada", "Recebimento em dinheiro", "Caixa", 1240, 26),
  ];
}

let estado: Estado | null = null;
const ouvintes = new Set<() => void>();

export let armazenamentoOk = true;

function carregar(): Estado {
  if (estado) return estado;
  if (typeof window === "undefined") return vazio;
  try {
    const bruto = window.localStorage.getItem(CHAVE);
    if (bruto) {
      estado = JSON.parse(bruto) as Estado;
      if (!estado.empresa) estado = { ...estado, empresa: empresaInicial() };
    } else {
      estado = estadoInicial();
      // grava o estado inicial já na primeira visita
      window.localStorage.setItem(CHAVE, JSON.stringify(estado));
    }
  } catch {
    armazenamentoOk = false;
    estado = estadoInicial();
  }
  return estado;
}

function salvar(novo: Estado) {
  estado = novo;
  try {
    window.localStorage.setItem(CHAVE, JSON.stringify(novo));
    armazenamentoOk = true;
  } catch {
    armazenamentoOk = false;
  }
  ouvintes.forEach((l) => l());
}

const vazio: Estado = { transacoes: [], orcamentos: [], metas: [], empresa: [] };

function subscrever(l: () => void) {
  ouvintes.add(l);
  return () => ouvintes.delete(l);
}

export function useFinancas() {
  const dados = useSyncExternalStore(
    subscrever,
    () => carregar(),
    () => vazio,
  );

  // Após a hidratação, avisa os assinantes para trocar o estado vazio do
  // servidor pelos dados reais salvos no navegador.
  useEffect(() => {
    carregar();
    ouvintes.forEach((l) => l());
  }, []);

  const atualizar = useCallback((fn: (e: Estado) => Estado) => {
    salvar(fn(carregar()));
  }, []);

  return {
    ...dados,
    adicionarTransacao: (t: Omit<Transacao, "id">) =>
      atualizar((e) => ({ ...e, transacoes: [{ ...t, id: crypto.randomUUID() }, ...e.transacoes] })),
    removerTransacao: (id: string) =>
      atualizar((e) => ({ ...e, transacoes: e.transacoes.filter((t) => t.id !== id) })),
    alternarPago: (id: string) =>
      atualizar((e) => ({
        ...e,
        transacoes: e.transacoes.map((t) => (t.id === id ? { ...t, pago: !t.pago } : t)),
      })),
    salvarOrcamento: (categoria: string, limite: number) =>
      atualizar((e) => {
        const existe = e.orcamentos.find((o) => o.categoria === categoria);
        return {
          ...e,
          orcamentos: existe
            ? e.orcamentos.map((o) => (o.categoria === categoria ? { ...o, limite } : o))
            : [...e.orcamentos, { id: crypto.randomUUID(), categoria, limite }],
        };
      }),
    removerOrcamento: (id: string) =>
      atualizar((e) => ({ ...e, orcamentos: e.orcamentos.filter((o) => o.id !== id) })),
    adicionarMeta: (m: Omit<Meta, "id">) =>
      atualizar((e) => ({ ...e, metas: [...e.metas, { ...m, id: crypto.randomUUID() }] })),
    aportarMeta: (id: string, valor: number) =>
      atualizar((e) => ({
        ...e,
        metas: e.metas.map((m) =>
          m.id === id ? { ...m, guardado: Math.max(0, m.guardado + valor) } : m,
        ),
      })),
    removerMeta: (id: string) =>
      atualizar((e) => ({ ...e, metas: e.metas.filter((m) => m.id !== id) })),
    adicionarLancamentoEmpresa: (l: Omit<LancamentoEmpresa, "id">) =>
      atualizar((e) => ({
        ...e,
        empresa: [{ ...l, id: crypto.randomUUID() }, ...(e.empresa ?? [])],
      })),
    removerLancamentoEmpresa: (id: string) =>
      atualizar((e) => ({ ...e, empresa: (e.empresa ?? []).filter((l) => l.id !== id) })),
    restaurarExemplo: () => salvar(estadoInicial()),
  };
}

/* ---------- utilidades ---------- */

export const brl = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export const MESES = [
  "jan",
  "fev",
  "mar",
  "abr",
  "mai",
  "jun",
  "jul",
  "ago",
  "set",
  "out",
  "nov",
  "dez",
];

export function chaveMes(data: string) {
  return data.slice(0, 7);
}

export function mesAtual() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function rotuloMes(chave: string) {
  const [ano, mes] = chave.split("-");
  return `${MESES[Number(mes) - 1]}/${ano?.slice(2)}`;
}

export function formatarData(data: string) {
  const [ano, mes, dia] = data.split("-");
  return `${dia}/${mes}/${ano}`;
}

export function diasAte(data: string) {
  const alvo = new Date(`${data}T00:00:00`);
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  return Math.round((alvo.getTime() - hoje.getTime()) / 86400000);
}

export function resumoMes(transacoes: Transacao[], mes: string) {
  const doMes = transacoes.filter((t) => chaveMes(t.data) === mes);
  const receitas = doMes.filter((t) => t.tipo === "receita").reduce((s, t) => s + t.valor, 0);
  const despesas = doMes.filter((t) => t.tipo === "despesa").reduce((s, t) => s + t.valor, 0);
  return { receitas, despesas, saldo: receitas - despesas, transacoes: doMes };
}

export function saldoAcumulado(transacoes: Transacao[]) {
  return transacoes.reduce((s, t) => s + (t.tipo === "receita" ? t.valor : -t.valor), 0);
}

export function serieMensal(transacoes: Transacao[], meses = 6) {
  const hoje = new Date();
  const saida: { mes: string; rotulo: string; receitas: number; despesas: number }[] = [];
  for (let i = meses - 1; i >= 0; i--) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth() - i, 1);
    const chave = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const r = resumoMes(transacoes, chave);
    saida.push({ mes: chave, rotulo: rotuloMes(chave), receitas: r.receitas, despesas: r.despesas });
  }
  return saida;
}

export function porCategoria(transacoes: Transacao[], mes: string) {
  const mapa = new Map<string, number>();
  transacoes
    .filter((t) => chaveMes(t.data) === mes && t.tipo === "despesa")
    .forEach((t) => mapa.set(t.categoria, (mapa.get(t.categoria) ?? 0) + t.valor));
  return [...mapa.entries()]
    .map(([categoria, valor]) => ({ categoria, valor }))
    .sort((a, b) => b.valor - a.valor);
}

export function contasAVencer(transacoes: Transacao[]) {
  return transacoes
    .filter((t) => t.tipo === "despesa" && !t.pago && diasAte(t.data) >= -30)
    .sort((a, b) => a.data.localeCompare(b.data))
    .slice(0, 6);
}

/* ---------- empresa ---------- */

export type Periodo = "dia" | "semana" | "mes";

function inicioSemana(d: Date) {
  const c = new Date(d);
  c.setHours(0, 0, 0, 0);
  c.setDate(c.getDate() - c.getDay());
  return c;
}

export function chavePeriodo(data: string, periodo: Periodo) {
  if (periodo === "mes") return data.slice(0, 7);
  if (periodo === "dia") return data;
  const d = inicioSemana(new Date(`${data}T00:00:00`));
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function rotuloPeriodo(chave: string, periodo: Periodo) {
  if (periodo === "mes") return rotuloMes(chave);
  if (periodo === "dia") return formatarData(chave).slice(0, 5);
  const d = new Date(`${chave}T00:00:00`);
  const fim = new Date(d);
  fim.setDate(fim.getDate() + 6);
  const f = (x: Date) => `${String(x.getDate()).padStart(2, "0")}/${String(x.getMonth() + 1).padStart(2, "0")}`;
  return `${f(d)}–${f(fim)}`;
}

export interface ResumoEmpresa {
  chave: string;
  rotulo: string;
  descricao: string;
  compras: number;
  vendas: number;
  entradas: number;
  resultado: number;
}

export function relatorioEmpresa(
  lancamentos: LancamentoEmpresa[],
  periodo: Periodo,
  limite = 12,
): ResumoEmpresa[] {
  const mapa = new Map<string, ResumoEmpresa>();
  const descricoes = new Map<string, string[]>();
  for (const l of lancamentos) {
    const chave = chavePeriodo(l.data, periodo);
    const atual =
      mapa.get(chave) ??
      { chave, rotulo: rotuloPeriodo(chave, periodo), descricao: "", compras: 0, vendas: 0, entradas: 0, resultado: 0 };
    if (l.tipo === "compra") atual.compras += l.valor;
    if (l.tipo === "venda") atual.vendas += l.valor;
    if (l.tipo === "entrada") atual.entradas += l.valor;
    atual.resultado = atual.vendas + atual.entradas - atual.compras;
    mapa.set(chave, atual);
    const lista = descricoes.get(chave) ?? [];
    lista.push(l.descricao);
    descricoes.set(chave, lista);
  }
  for (const r of mapa.values()) {
    const ds = descricoes.get(r.chave) ?? [];
    r.descricao = ds.slice(0, 5).join(", ") + (ds.length > 5 ? ` e +${ds.length - 5}` : "");
  }
  return [...mapa.values()].sort((a, b) => a.chave.localeCompare(b.chave)).slice(-limite);
}

export function totaisEmpresa(lancamentos: LancamentoEmpresa[]) {
  const soma = (t: TipoEmpresa) =>
    lancamentos.filter((l) => l.tipo === t).reduce((s, l) => s + l.valor, 0);
  const compras = soma("compra");
  const vendas = soma("venda");
  const entradas = soma("entrada");
  return { compras, vendas, entradas, resultado: vendas + entradas - compras };
}

/* ---------- relatório de transações por período ---------- */

export interface LinhaRelatorio {
  chave: string;
  rotulo: string;
  receitas: number;
  despesas: number;
  saldo: number;
  descricao: string;
}

export function relatorioTransacoes(
  transacoes: Transacao[],
  periodo: Periodo,
  limite = 14,
): LinhaRelatorio[] {
  const mapa = new Map<string, LinhaRelatorio>();
  for (const t of transacoes) {
    const chave = chavePeriodo(t.data, periodo);
    const atual =
      mapa.get(chave) ??
      {
        chave,
        rotulo: rotuloPeriodo(chave, periodo),
        receitas: 0,
        despesas: 0,
        saldo: 0,
        descricao: "",
      };
    if (t.tipo === "receita") atual.receitas += t.valor;
    else atual.despesas += t.valor;
    atual.saldo = atual.receitas - atual.despesas;
    atual.descricao = atual.descricao
      ? atual.descricao + ", " + t.descricao
      : t.descricao;
    mapa.set(chave, atual);
  }
  return [...mapa.values()].sort((a, b) => a.chave.localeCompare(b.chave)).slice(-limite);
}
