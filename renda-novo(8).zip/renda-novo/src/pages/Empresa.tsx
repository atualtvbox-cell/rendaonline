import { useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AppShell, PageHeader } from "@/components/AppShell";
import { brl, chavePeriodo, formatarData, relatorioEmpresa, ROTULO_EMPRESA, totaisEmpresa, useFinancas, type Periodo, type TipoEmpresa } from "@/lib/finance";

const campo = "w-full rounded-xl border border-input bg-surface-2 px-3 py-2.5 text-sm outline-none focus:border-ring";
const CORES: Record<TipoEmpresa, string> = { compra: "var(--color-negative)", venda: "var(--color-positive)", entrada: "var(--color-chart-1)" };
const PERIODOS: { valor: Periodo; rotulo: string }[] = [{ valor: "dia", rotulo: "Diário" }, { valor: "semana", rotulo: "Semanal" }, { valor: "mes", rotulo: "Mensal" }];
const hojeISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };

export default function Empresa() {
  const { empresa, adicionarLancamentoEmpresa, removerLancamentoEmpresa, carregando } = useFinancas();
  const lancamentos = empresa ?? [];
  const [aba, setAba] = useState<"todos" | TipoEmpresa>("todos");
  const [periodo, setPeriodo] = useState<Periodo>("dia");
  const [filtroAtivo, setFiltroAtivo] = useState(false);
  const [filtroPeriodo, setFiltroPeriodo] = useState<Periodo>("mes");
  const [filtroData, setFiltroData] = useState(hojeISO());
  const [form, setForm] = useState({ tipo: "venda" as TipoEmpresa, descricao: "", contraparte: "", valor: "", data: hojeISO() });

  const lista = useMemo(() => lancamentos.filter((l) => (aba === "todos" ? true : l.tipo === aba)).filter((l) => !filtroAtivo ? true : chavePeriodo(l.data, filtroPeriodo) === chavePeriodo(filtroData, filtroPeriodo)).sort((a, b) => b.data.localeCompare(a.data)), [lancamentos, aba, filtroAtivo, filtroPeriodo, filtroData]);
  const totaisLista = useMemo(() => totaisEmpresa(lista), [lista]);
  const totais = useMemo(() => totaisEmpresa(lancamentos), [lancamentos]);
  const relatorio = useMemo(() => relatorioEmpresa(lancamentos, periodo, periodo === "dia" ? 31 : 12), [lancamentos, periodo]);

  function enviar(e: React.FormEvent) {
    e.preventDefault();
    const valor = Number(form.valor.replace(",", "."));
    if (!form.descricao.trim() || !Number.isFinite(valor) || valor <= 0) return;
    adicionarLancamentoEmpresa({ ...form, valor });
    setForm({ ...form, descricao: "", contraparte: "", valor: "" });
  }

  if (carregando) return <AppShell><p className="py-12 text-center text-muted-foreground">Carregando...</p></AppShell>;

  return (
    <AppShell>
      <PageHeader titulo="Empresa" descricao="Compras, vendas e entradas de dinheiro do negócio, com relatórios diário, semanal e mensal." />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Cartao rotulo="Vendas" valor={totais.vendas} cor="text-positive" />
        <Cartao rotulo="Compras" valor={totais.compras} cor="text-negative" />
        <Cartao rotulo="Entradas de recursos" valor={totais.entradas} cor="text-foreground" />
        <Cartao rotulo="Resultado" valor={totais.resultado} cor={totais.resultado >= 0 ? "text-positive" : "text-negative"} />
      </div>
      <section className="panel mt-4 p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-sm font-semibold">Relatório por período</h2>
          <div className="flex gap-1 rounded-xl bg-surface-2 p-1 text-sm">{PERIODOS.map((p) => (<button key={p.valor} type="button" onClick={() => setPeriodo(p.valor)} className={`rounded-lg px-3 py-1.5 transition-colors ${periodo === p.valor ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{p.rotulo}</button>))}</div>
        </div>
        <div className="mt-5 h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={relatorio} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="var(--color-border)" />
              <XAxis dataKey="rotulo" tickLine={false} axisLine={false} stroke="var(--color-muted-foreground)" fontSize={11} />
              <YAxis tickLine={false} axisLine={false} stroke="var(--color-muted-foreground)" fontSize={11} tickFormatter={(v: number) => `${Math.round(v / 1000)}k`} />
              <Tooltip formatter={(v: number) => brl(v)} contentStyle={{ background: "var(--color-surface-2)", border: "1px solid var(--color-border)", borderRadius: 12, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="vendas" name="Vendas" fill={CORES.venda} radius={[4, 4, 0, 0]} />
              <Bar dataKey="entradas" name="Entradas" fill={CORES.entrada} radius={[4, 4, 0, 0]} />
              <Bar dataKey="compras" name="Compras" fill={CORES.compra} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <form onSubmit={enviar} className="panel space-y-3 p-6">
          <h2 className="text-sm font-semibold">Novo lançamento da empresa</h2>
          <select className={campo} value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value as TipoEmpresa })}><option value="venda">Venda</option><option value="compra">Compra</option><option value="entrada">Entrada de recursos</option></select>
          <input className={campo} placeholder="Descrição" value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} />
          <input className={campo} placeholder="Cliente / fornecedor / origem" value={form.contraparte} onChange={(e) => setForm({ ...form, contraparte: e.target.value })} />
          <input className={campo} placeholder="Valor (R$)" inputMode="decimal" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} />
          <input type="date" className={campo} value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} />
          <button type="submit" className="w-full rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90">Adicionar</button>
        </form>
        <section className="panel p-6 lg:col-span-2">
          <h2 className="mb-3 text-sm font-semibold">Histórico de entradas e saídas</h2>
          <div className="flex flex-wrap gap-2">
            <div className="flex gap-1 rounded-xl bg-surface-2 p-1 text-sm">
              {(["todos", "compra", "venda", "entrada"] as const).map((a) => (<button key={a} type="button" onClick={() => setAba(a)} className={`rounded-lg px-3 py-1.5 transition-colors ${aba === a ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{a === "todos" ? "Todos" : a === "entrada" ? "Entradas" : `${ROTULO_EMPRESA[a]}s`}</button>))}
            </div>
            <div className="flex gap-1 rounded-xl bg-surface-2 p-1 text-sm">
              <button type="button" onClick={() => setFiltroAtivo(false)} className={`rounded-lg px-3 py-1.5 transition-colors ${!filtroAtivo ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>Tudo</button>
              {PERIODOS.map((p) => (<button key={p.valor} type="button" onClick={() => { setFiltroAtivo(true); setFiltroPeriodo(p.valor); }} className={`rounded-lg px-3 py-1.5 transition-colors ${filtroAtivo && filtroPeriodo === p.valor ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{p.rotulo}</button>))}
            </div>
            {filtroAtivo && <input type="date" className="rounded-xl border border-input bg-surface-2 px-3 py-1.5 text-sm outline-none focus:border-ring" value={filtroData} onChange={(e) => setFiltroData(e.target.value)} />}
          </div>
          <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-xs text-muted-foreground">
            <span>Entradas: <span className="num text-positive">{brl(totaisLista.vendas + totaisLista.entradas)}</span></span>
            <span>Saídas: <span className="num text-negative">{brl(totaisLista.compras)}</span></span>
            <span>Saldo: <span className={`num ${totaisLista.resultado >= 0 ? "text-positive" : "text-negative"}`}>{brl(totaisLista.resultado)}</span></span>
            <span>{lista.length} lançamento(s)</span>
          </div>
          <div className="mt-4 divide-y divide-border">
            {lista.map((l) => (
              <div key={l.id} className="flex items-center gap-3 py-3">
                <span className="size-2 shrink-0 rounded-full" style={{ background: CORES[l.tipo] }} />
                <div className="min-w-0 flex-1"><div className="truncate text-sm">{l.descricao}</div><div className="truncate text-xs text-muted-foreground">{ROTULO_EMPRESA[l.tipo]}{l.contraparte ? ` · ${l.contraparte}` : ""} · {formatarData(l.data)}</div></div>
                <span className={`num text-sm font-medium ${l.tipo === "compra" ? "text-negative" : "text-positive"}`}>{l.tipo === "compra" ? "−" : "+"} {brl(l.valor)}</span>
                <button type="button" onClick={() => removerLancamentoEmpresa(l.id)} className="rounded-lg px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-secondary hover:text-negative">excluir</button>
              </div>))}
            {lista.length === 0 && <p className="py-6 text-sm text-muted-foreground">{filtroAtivo ? "Nenhum lançamento nesta data." : "Nenhum lançamento nesta aba."}</p>}
          </div>
        </section>
      </div>
    </AppShell>
  );
}

function Cartao({ rotulo, valor, cor }: { rotulo: string; valor: number; cor: string }) {
  return (<div className="panel p-5"><p className="text-xs text-muted-foreground">{rotulo}</p><p className={`num mt-1.5 text-xl font-semibold ${cor}`}>{brl(valor)}</p></div>);
}
