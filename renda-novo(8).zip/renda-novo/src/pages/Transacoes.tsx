import { useEffect, useMemo, useState } from "react";
import { AppShell, PageHeader } from "@/components/AppShell";
import { brl, formatarData, useFinancas } from "@/lib/finance";
import { listarCategorias } from "@/lib/api";

var campo = "w-full rounded-xl border border-input bg-surface-2 px-3 py-2.5 text-sm outline-none focus:border-ring";

export default function Transacoes() {
  var { transacoes, adicionarTransacao, removerTransacao, alternarPago, carregando } = useFinancas();
  var [filtro, setFiltro] = useState("todas");
  var [busca, setBusca] = useState("");
  var [categorias, setCategorias] = useState([]);
  var [form, setForm] = useState({ descricao: "", valor: "", tipo: "despesa", recorrencia: "variavel", categoria: "Alimentacao", data: new Date().toISOString().slice(0, 10), pago: true });

  useEffect(function() {
    listarCategorias().then(function(cats) {
      setCategorias(cats);
      if (cats.length > 0 && !form.categoria) {
        setForm(function(f) { return { ...f, categoria: cats.nome }; });
      }
    });
  }, []);

  var lista = useMemo(function() {
    return transacoes
      .filter(function(t) { return filtro === "todas" ? true : t.tipo === filtro; })
      .filter(function(t) { return t.descricao.toLowerCase().includes(busca.toLowerCase().trim()); })
      .sort(function(a, b) { return b.data.localeCompare(a.data); });
  }, [transacoes, filtro, busca]);

  function enviar(e) {
    e.preventDefault();
    var valor = Number(form.valor.replace(",", "."));
    if (!form.descricao.trim() || !Number.isFinite(valor) || valor <= 0) return;
    adicionarTransacao({ ...form, valor: valor });
    setForm({ ...form, descricao: "", valor: "" });
  }

  if (carregando) return (<AppShell><p className="py-12 text-center text-muted-foreground">Carregando...</p></AppShell>);

  return (
    <AppShell>
      <PageHeader titulo="Transações" descricao="Registre receitas e despesas, marque o que é fixo e o que é variável." />
      <div className="grid gap-4 lg:grid-cols-3">
        <form onSubmit={enviar} className="panel space-y-3 p-6 lg:col-span-1">
          <h2 className="text-sm font-semibold">Novo lançamento</h2>
          <input className={campo} placeholder="Descrição" value={form.descricao} onChange={function(e) { setForm({ ...form, descricao: e.target.value }); }} />
          <input className={campo} placeholder="Valor (R$)" inputMode="decimal" value={form.valor} onChange={function(e) { setForm({ ...form, valor: e.target.value }); }} />
          <div className="grid grid-cols-2 gap-3">
            <select className={campo} value={form.tipo} onChange={function(e) { setForm({ ...form, tipo: e.target.value }); }}>
              <option value="despesa">Despesa</option>
              <option value="receita">Receita</option>
            </select>
            <select className={campo} value={form.recorrencia} onChange={function(e) { setForm({ ...form, recorrencia: e.target.value }); }}>
              <option value="variavel">Variável</option>
              <option value="fixa">Fixa</option>
            </select>
          </div>
          <select className={campo} value={form.categoria} onChange={function(e) { setForm({ ...form, categoria: e.target.value }); }}>
            {categorias.map(function(c) { return (<option key={c.id} value={c.nome}>{c.nome}</option>); })}
          </select>
          <input type="date" className={campo} value={form.data} onChange={function(e) { setForm({ ...form, data: e.target.value }); }} />
          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            <input type="checkbox" checked={form.pago} onChange={function(e) { setForm({ ...form, pago: e.target.checked }); }} className="size-4 accent-[var(--color-primary)]" />
            Já foi pago / recebido
          </label>
          <button type="submit" className="w-full rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90">Adicionar</button>
        </form>
        <section className="panel p-6 lg:col-span-2">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex gap-1 rounded-xl bg-surface-2 p-1 text-sm">
              {[{v:"todas",r:"Todas"},{v:"receita",r:"Receitas"},{v:"despesa",r:"Despesas"}].map(function(f) { return (
                <button key={f.v} type="button" onClick={function() { setFiltro(f.v); }}
                  className={"rounded-lg px-3 py-1.5 capitalize transition-colors " + (filtro === f.v ? "bg-primary text-primary-foreground" : "text-muted-foreground")}>{f.r}</button>
              ); })}
            </div>
            <input className={campo + " sm:max-w-56"} placeholder="Buscar por descrição" value={busca} onChange={function(e) { setBusca(e.target.value); }} />
          </div>
          <div className="mt-4 divide-y divide-border">
            {lista.map(function(t) { return (
              <div key={t.id} className="flex items-center gap-3 py-3">
                <button type="button" onClick={function() { alternarPago(t.id); }} title={t.pago ? "Marcar como pendente" : "Marcar como pago"} className={"size-4 shrink-0 rounded-full border transition-colors " + (t.pago ? "border-primary bg-primary" : "border-border")} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm">{t.descricao}</div>
                  <div className="text-xs text-muted-foreground">{t.categoria} · {t.recorrencia} · {formatarData(t.data)}{!t.pago && <span className="text-warning"> · pendente</span>}</div>
                </div>
                <span className={"num text-sm font-medium " + (t.tipo === "receita" ? "text-positive" : "text-negative")}>{t.tipo === "receita" ? "+" : "-"} {brl(t.valor)}</span>
                <button type="button" onClick={function() { removerTransacao(t.id); }} className="rounded-lg px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-secondary hover:text-negative">excluir</button>
              </div>
            ); })}
            {lista.length === 0 && <p className="py-6 text-sm text-muted-foreground">Nenhuma transação encontrada.</p>}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
