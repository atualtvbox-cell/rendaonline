import { useState } from "react";
import { login } from "@/lib/api";

export default function Login({ onLogin }) {
  var [nome, setNome] = useState("");
  var [senha, setSenha] = useState("");
  var [erro, setErro] = useState("");

  async function enviar(e) {
    e.preventDefault();
    setErro("");
    if (!nome.trim() || !senha.trim()) { setErro("Preencha nome e senha"); return; }
    try {
      var res = await login(nome.trim(), senha.trim());
      if (res.ok) {
        localStorage.setItem("renda:usuario", JSON.stringify({ id: res.id, nome: res.nome }));
        onLogin({ id: res.id, nome: res.nome });
      } else {
        setErro(res.erro || "Usuario ou senha incorretos");
      }
    } catch(err) {
      setErro("Erro de conexao com o servidor");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-sm panel p-8">
        <div className="flex items-center justify-center gap-2 mb-6">
          <span className="grid size-10 place-items-center rounded-xl bg-primary font-display text-lg font-bold text-primary-foreground">R</span>
          <span className="font-display text-xl font-semibold">Renda</span>
        </div>
        <h2 className="text-center text-lg font-semibold mb-4">Entrar</h2>
        <form onSubmit={enviar} className="space-y-3">
          <input type="text" value={nome} onChange={function(e) { setNome(e.target.value); }} placeholder="Usuário" className="w-full rounded-xl border border-input bg-surface-2 px-3 py-2.5 text-sm outline-none focus:border-ring" />
          <input type="password" value={senha} onChange={function(e) { setSenha(e.target.value); }} placeholder="Senha" className="w-full rounded-xl border border-input bg-surface-2 px-3 py-2.5 text-sm outline-none focus:border-ring" />
          {erro && <p className="text-sm text-red-500">{erro}</p>}
          <button type="submit" className="w-full rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90">Entrar</button>
        </form>
        <p className="mt-4 text-center text-xs text-muted-foreground">Usuário padrão: admin / Senha: 1234</p>
      </div>
    </div>
  );
}
