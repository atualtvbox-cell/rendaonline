import { useMemo, useState } from "react";
import { AppShell, PageHeader } from "@/components/AppShell";
import { brl, CORES_CATEGORIA, mesAtual, porCategoria, resumoMes, serieMensal, useFinancas, formatarData } from "@/lib/finance";
import { CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

function getHoje() {
  var d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function getInicioSemana() {
  var d = new Date();
  var dia = d.getDay();
  d.setDate(d.getDate() - dia);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function getFimSemana() {
  var d = new Date();
  var dia = d.getDay();
  d.setDate(d.getDate() + (6 - dia));
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function getMeses() {
  var lista = [];
  var d = new Date();
  for (var i = 0; i < 12; i++) {
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var a = d.getFullYear();
    lista.push({ valor: a + "-" + m, rotulo: m + "/" + a });
    d.setMonth(d.getMonth() - 1);
  }
  return lista;
}

function getInicioMesPor(mesStr) {
  return mesStr + "-01";
}

function getFimMesPor(mesStr) {
  var parts = mesStr.split("-");
  var ultimo = new Date(Number(parts.shift()), Number(parts.shift()), 0);
  return mesStr + "-" + String(ultimo.getDate()).padStart(2, "0");
}

export default function Relatorios() {
  var { transacoes, carregando } = useFinancas();
  var mes = mesAtual();
  var [periodo, setPeriodo] = useState("dia");
  var [mesSelec, setMesSelec] = useState(mes);
  var meses = getMeses();

  var serie = useMemo(
    function() { return serieMensal(transacoes, 6).map(function(s) { return { ...s, saldo: s.receitas - s.despesas }; }); },
    [transacoes]
  );

  var categorias = useMemo(function() { return porCategoria(transacoes, mesSelec); }, [transacoes, mesSelec]);
  var resumo = useMemo(function() { return resumoMes(transacoes, mesSelec); }, [transacoes, mesSelec]);
  var totalCategorias = categorias.reduce(function(s, c) { return s + c.valor; }, 0);
  var maiorCategoria = categorias.length > 0 ? categorias.sort(function(a,b){return b.valor-a.valor;}) : null;

  var mesesComGasto = serie.filter(function(m) { return m.despesas > 0; });
  var mediaDespesas = mesesComGasto.length > 0 ? mesesComGasto.reduce(function(s, m) { return s + m.despesas; }, 0) / mesesComGasto.length : 0;
  var variacao = mediaDespesas > 0 ? ((resumo.despesas - mediaDespesas) / mediaDespesas) * 100 : 0;
  var taxaPoupanca = resumo.receitas > 0 ? (resumo.saldo / resumo.receitas) * 100 : 0;

  var transacoesFiltradas = useMemo(function() {
    var inicio = "";
    var fim = "";
    if (periodo === "dia") {
      inicio = getHoje();
      fim = getHoje();
    } else if (periodo === "semana") {
      inicio = getInicioSemana();
      fim = getFimSemana();
    } else {
      inicio = getInicioMesPor(mesSelec);
      fim = getFimMesPor(mesSelec);
    }
    return transacoes
      .filter(function(t) { return t.data >= inicio && t.data <= fim; })
      .sort(function(a, b) { return a.data.localeCompare(b.data); });
  }, [transacoes, periodo, mesSelec]);

  var totalReceitas = 0;
  var totalDespesas = 0;
  for (var i = 0; i < transacoesFiltradas.length; i++) {
    if (transacoesFiltradas[i].tipo === "receita") {
      totalReceitas += transacoesFiltradas[i].valor;
    } else {
      totalDespesas += transacoesFiltradas[i].valor;
    }
  }
  var totalSaldo = totalReceitas - totalDespesas;

  var diasAgrupados = {};
  for (var j = 0; j < transacoesFiltradas.length; j++) {
    var t = transacoesFiltradas[j];
    if (!diasAgrupados[t.data]) { diasAgrupados[t.data] = []; }
    diasAgrupados[t.data].push(t);
  }
  var diasOrdenados = Object.keys(diasAgrupados).sort();

  var tituloRelatorio = "Relatório do dia " + formatarData(getHoje());
  if (periodo === "semana") {
    tituloRelatorio = "Relatório semanal: " + formatarData(getInicioSemana()) + " a " + formatarData(getFimSemana());
  } else if (periodo === "mes") {
    tituloRelatorio = "Relatório mensal: " + formatarData(getInicioMesPor(mesSelec)) + " a " + formatarData(getFimMesPor(mesSelec));
  }

  if (carregando) {
    return (<AppShell><p className="py-12 text-center text-muted-foreground">Carregando...</p></AppShell>);
  }

  return (
    <AppShell>
      <PageHeader titulo="Relatórios" descricao="Como seus gastos evoluem ao longo do tempo e para onde o dinheiro está indo." />

      <div className="mb-4 flex items-center gap-3">
        <span className="text-sm font-medium">Mês:</span>
        <select value={mesSelec} onChange={function(e) { setMesSelec(e.target.value); }}
          className="rounded-lg border border-border bg-surface-2 px-3 py-1.5 text-sm">
          {meses.map(function(m) { return (<option key={m.valor} value={m.valor}>{m.rotulo}</option>); })}
        </select>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="panel p-5">
          <div className="text-xs text-muted-foreground">Taxa de poupança</div>
          <div className={"num mt-1.5 text-2xl font-bold " + (taxaPoupanca >= 0 ? "text-positive" : "text-negative")}>{taxaPoupanca.toFixed(1)}%</div>
        </div>
        <div className="panel p-5">
          <div className="text-xs text-muted-foreground">Despesas vs. média 6 meses</div>
          <div className={"num mt-1.5 text-2xl font-bold " + (variacao > 0 ? "text-negative" : "text-positive")}>{variacao > 0 ? "+" : ""}{variacao.toFixed(1)}%</div>
        </div>
        <div className="panel p-5">
          <div className="text-xs text-muted-foreground">Maior categoria</div>
          <div className="mt-1.5 text-2xl font-bold">{maiorCategoria ? maiorCategoria.categoria : "—"}</div>
          <div className="num text-xs text-muted-foreground">{maiorCategoria ? brl(maiorCategoria.valor) : "sem gastos"}</div>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <section className="panel p-6 lg:col-span-2">
          <h2 className="text-sm font-semibold">Tendência · receitas, despesas e saldo</h2>
          <div className="mt-5 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={serie}>
                <CartesianGrid vertical={false} stroke="var(--color-border)" />
                <XAxis dataKey="rotulo" tickLine={false} axisLine={false} tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} width={70} tickFormatter={function(v) { return "R$ " + Math.round(v / 1000) + "k"; }} />
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 12, color: "var(--color-foreground)" }} formatter={function(v) { return brl(Number(v)); }} />
                <Line type="monotone" dataKey="receitas" name="Receitas" stroke="var(--color-positive)" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="despesas" name="Despesas" stroke="var(--color-negative)" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="saldo" name="Saldo" stroke="var(--color-warning)" strokeWidth={2} strokeDasharray="5 4" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="panel p-6">
          <h2 className="text-sm font-semibold">Gastos por categoria</h2>
          {categorias.length > 0 ? (
            <div>
              <div className="mt-2 h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={categorias} dataKey="valor" nameKey="categoria" innerRadius={52} outerRadius={80} paddingAngle={2} stroke="none">
                      {categorias.map(function(c) { return (<Cell key={c.categoria} fill={CORES_CATEGORIA[c.categoria] || "var(--color-chart-4)"} />); })}
                    </Pie>
                    <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 12, color: "var(--color-foreground)" }} formatter={function(v) { return brl(Number(v)); }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-2 space-y-2">
                {categorias.map(function(c) { return (
                  <div key={c.categoria} className="flex items-center gap-2 text-sm">
                    <span className="size-2.5 rounded-full" style={{ background: CORES_CATEGORIA[c.categoria] || "var(--color-chart-4)" }} />
                    <span className="flex-1 truncate">{c.categoria}</span>
                    <span className="num text-xs text-muted-foreground">{totalCategorias > 0 ? Math.round((c.valor / totalCategorias) * 100) : 0}%</span>
                    <span className="num text-xs">{brl(c.valor)}</span>
                  </div>
                ); })}
              </div>
            </div>
          ) : (
            <p className="mt-4 text-sm text-muted-foreground">Sem despesas registradas neste mês.</p>
          )}
        </section>
      </div>

      <section className="panel mt-4 p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-sm font-semibold">Lançamentos por período</h2>
          <div className="flex gap-1 rounded-xl bg-surface-2 p-1 text-sm">
            {[{ valor: "dia", rotulo: "Diário" }, { valor: "semana", rotulo: "Semanal" }, { valor: "mes", rotulo: "Mensal" }].map(function(p) { return (
              <button key={p.valor} type="button" onClick={function() { setPeriodo(p.valor); }}
                className={"rounded-lg px-3 py-1.5 transition-colors " + (periodo === p.valor ? "bg-primary text-primary-foreground" : "text-muted-foreground")}>{p.rotulo}</button>
            ); })}
          </div>
        </div>

        <h3 className="mt-4 text-sm font-semibold">{tituloRelatorio}</h3>

        <div className="mt-3">
          {diasOrdenados.length === 0 && (
            <p className="py-6 text-sm text-muted-foreground">Nenhum lançamento registrado neste período.</p>
          )}
          {diasOrdenados.map(function(dia) {
            var itens = diasAgrupados[dia];
            return (
              <div key={dia} className="mb-4">
                {periodo !== "dia" && (
                  <div className="mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    {"Dia " + formatarData(dia)}
                  </div>
                )}
                <div className="divide-y divide-border rounded-xl border border-border">
                  {itens.map(function(t) { return (
                    <div key={t.id} className="flex items-center gap-3 px-4 py-3">
                      <span className="text-xs text-muted-foreground whitespace-nowrap">{formatarData(t.data)}</span>
                      <span className="flex-1 truncate text-sm">{t.descricao}</span>
                      <span className={"rounded-lg px-2 py-0.5 text-xs font-medium " + (t.tipo === "receita" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800")}>
                        {t.tipo === "receita" ? "Receita" : "Despesa"}
                      </span>
                      <span className={"num text-sm font-medium " + (t.tipo === "receita" ? "text-positive" : "text-negative")}>
                        {t.tipo === "receita" ? "+" : "-"} {brl(t.valor)}
                      </span>
                    </div>
                  ); })}
                </div>
              </div>
            );
          })}
        </div>

        {transacoesFiltradas.length > 0 && (
          <div className="mt-4 rounded-xl bg-surface-2 p-4">
            <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
              {periodo === "dia" ? "Resumo do dia" : periodo === "semana" ? "Resumo da semana" : "Resumo do mês"}
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <div className="text-xs text-muted-foreground">Receitas</div>
                <div className="num text-lg font-semibold text-positive">{brl(totalReceitas)}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Despesas</div>
                <div className="num text-lg font-semibold text-negative">{brl(totalDespesas)}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Saldo</div>
                <div className={"num text-lg font-semibold " + (totalSaldo >= 0 ? "text-positive" : "text-negative")}>{brl(totalSaldo)}</div>
              </div>
            </div>
          </div>
        )}
      </section>
    </AppShell>
  );
}
