import { Link } from "react-router-dom";
import { AppShell, PageHeader } from "@/components/AppShell";
import { brl, contasAVencer, diasAte, formatarData, mesAtual, resumoMes, saldoAcumulado, serieMensal, useFinancas } from "@/lib/finance";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis } from "recharts";

export default function Painel() {
  const { transacoes, carregando } = useFinancas();
  const mes = mesAtual();
  const resumo = resumoMes(transacoes, mes);
  const serie = serieMensal(transacoes);
  const vencendo = contasAVencer(transacoes);
  const saldo = saldoAcumulado(transacoes);

  if (carregando) return <AppShell><p className="py-12 text-center text-muted-foreground">Carregando dados do banco...</p></AppShell>;

  return (
    <AppShell>
      <PageHeader titulo="Painel" descricao="Uma visão completa do seu mês: quanto entrou, quanto saiu e o que ainda vence."
        acao={<Link to="/transacoes" className="rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90">+ Nova transação</Link>} />
      <div className="grid gap-4 lg:grid-cols-3">
        <section className="panel p-6 lg:col-span-2">
          <div className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Saldo acumulado</div>
          <div className="num mt-2 text-4xl font-bold sm:text-5xl">{brl(saldo)}</div>
          <div className="mt-6 grid grid-cols-3 gap-4 border-t border-border pt-5">
            <div><div className="text-xs text-muted-foreground">Receitas do mês</div><div className="num mt-1 text-lg font-semibold text-positive">{brl(resumo.receitas)}</div></div>
            <div><div className="text-xs text-muted-foreground">Despesas do mês</div><div className="num mt-1 text-lg font-semibold text-negative">{brl(resumo.despesas)}</div></div>
            <div><div className="text-xs text-muted-foreground">Resultado</div><div className={`num mt-1 text-lg font-semibold ${resumo.saldo >= 0 ? "text-positive" : "text-negative"}`}>{brl(resumo.saldo)}</div></div>
          </div>
        </section>
        <section className="panel p-6">
          <h2 className="text-sm font-semibold">Contas a vencer</h2>
          <div className="mt-4 space-y-2">
            {vencendo.length === 0 && <p className="text-sm text-muted-foreground">Nenhuma conta em aberto. Tudo em dia.</p>}
            {vencendo.map((t) => { const dias = diasAte(t.data); const urgente = dias <= 3; return (
              <div key={t.id} className="flex items-center justify-between rounded-xl bg-surface-2 px-3 py-2.5">
                <div className="min-w-0"><div className="truncate text-sm">{t.descricao}</div>
                  <div className={`text-xs ${urgente ? "text-negative" : "text-muted-foreground"}`}>{dias < 0 ? `atrasada há ${Math.abs(dias)} dia(s)` : dias === 0 ? "vence hoje" : `em ${dias} dia(s)`}</div>
                </div><span className="num text-sm font-medium">{brl(t.valor)}</span>
              </div>); })}
          </div>
        </section>
        <section className="panel p-6 lg:col-span-2">
          <h2 className="text-sm font-semibold">Receitas x despesas · últimos 6 meses</h2>
          <div className="mt-5 h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={serie} barGap={4}>
                <CartesianGrid vertical={false} stroke="var(--color-border)" />
                <XAxis dataKey="rotulo" tickLine={false} axisLine={false} tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
                <Tooltip cursor={{ fill: "var(--color-accent)" }} contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 12, color: "var(--color-foreground)" }} formatter={(v: number) => brl(v)} />
                <Bar dataKey="receitas" name="Receitas" fill="var(--color-positive)" radius={4} />
                <Bar dataKey="despesas" name="Despesas" fill="var(--color-negative)" radius={4} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>
        <section className="panel p-6 lg:col-span-3">
          <div className="flex items-center justify-between"><h2 className="text-sm font-semibold">Transações do mês</h2><Link to="/transacoes" className="text-xs text-primary hover:underline">ver todas</Link></div>
          <div className="mt-3 divide-y divide-border">
            {resumo.transacoes.slice(0, 6).map((t) => (
              <div key={t.id} className="flex items-center gap-3 py-3">
                <span className="size-2.5 shrink-0 rounded-full" style={{ background: t.tipo === "receita" ? "var(--color-positive)" : "var(--color-negative)" }} />
                <div className="min-w-0 flex-1"><div className="truncate text-sm">{t.descricao}</div><div className="text-xs text-muted-foreground">{t.categoria} · {t.recorrencia} · {formatarData(t.data)}</div></div>
                <span className={`num text-sm font-medium ${t.tipo === "receita" ? "text-positive" : "text-negative"}`}>{t.tipo === "receita" ? "+" : "−"} {brl(t.valor)}</span>
              </div>))}
            {resumo.transacoes.length === 0 && <p className="py-4 text-sm text-muted-foreground">Nenhuma transação registrada neste mês.</p>}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
