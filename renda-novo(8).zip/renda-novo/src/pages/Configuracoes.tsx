import { useState, useEffect } from "react";
import { AppShell, PageHeader } from "@/components/AppShell";
import { listarCategorias, criarCategoria, removerCategoria, listarContas, criarConta, removerConta, atualizarUsuario } from "@/lib/api";

export default function Configuracoes() {
  var [categorias, setCategorias] = useState([]);
  var [novaCategoria, setNovaCategoria] = useState("");
  var [contas, setContas] = useState([]);
  var [novaConta, setNovaConta] = useState({ banco: "", agencia: "", conta: "", tipo: "corrente", titular: "" });
  var [aba, setAba] = useState("categorias");
  var [novoNome, setNovoNome] = useState("");
  var [novaSenha, setNovaSenha] = useState("");
  var [msgUsuario, setMsgUsuario] = useState("");

  async function salvarUsuario() {
    if (!novoNome.trim() || !novaSenha.trim()) { setMsgUsuario("Preencha nome e senha"); return; }
    try {
      var salvo = JSON.parse(localStorage.getItem("renda:usuario") || "{}");
      var res = await atualizarUsuario(salvo.id, novoNome.trim(), novaSenha.trim());
      if (res.ok) {
        localStorage.setItem("renda:usuario", JSON.stringify({ id: salvo.id, nome: novoNome.trim() }));
        setMsgUsuario("Salvo com sucesso! Use o novo login na proxima vez.");
        setNovoNome("");
        setNovaSenha("");
      }
    } catch(e) { setMsgUsuario("Erro ao salvar"); }
  }

  useEffect(function() { carregarDados(); }, []);

  async function carregarDados() {
    var cats = await listarCategorias();
    setCategorias(cats);
    var cts = await listarContas();
    setContas(cts);
  }

  async function adicionarCategoria() {
    if (!novaCategoria.trim()) return;
    await criarCategoria(novaCategoria.trim());
    setNovaCategoria("");
    carregarDados();
  }

  async function excluirCategoria(id) {
    if (!confirm("Deseja excluir esta categoria?")) return;
    await removerCategoria(id);
    carregarDados();
  }

  async function adicionarConta() {
    if (!novaConta.banco.trim() || !novaConta.agencia.trim() || !novaConta.conta.trim()) return;
    await criarConta(novaConta);
    setNovaConta({ banco: "", agencia: "", conta: "", tipo: "corrente", titular: "" });
    carregarDados();
  }

  async function excluirConta(id) {
    if (!confirm("Deseja excluir esta conta bancária?")) return;
    await removerConta(id);
    carregarDados();
  }

  return (
    <AppShell>
      <PageHeader titulo="Configurações" descricao="Gerencie categorias e contas bancárias." />

      <div className="flex gap-2 mb-4">
        <button type="button" onClick={function() { setAba("categorias"); }}
          className={"rounded-lg px-4 py-2 text-sm font-medium transition-colors " + (aba === "categorias" ? "bg-primary text-primary-foreground" : "bg-surface-2 text-muted-foreground")}>
          Categorias
        </button>
        <button type="button" onClick={function() { setAba("contas"); }}
          className={"rounded-lg px-4 py-2 text-sm font-medium transition-colors " + (aba === "contas" ? "bg-primary text-primary-foreground" : "bg-surface-2 text-muted-foreground")}>
          Contas Bancárias
        </button>
        <button type="button" onClick={function() { setAba("usuario"); }}
          className={"rounded-lg px-4 py-2 text-sm font-medium transition-colors " + (aba === "usuario" ? "bg-primary text-primary-foreground" : "bg-surface-2 text-muted-foreground")}>
          Usuário e Senha
        </button>
      </div>

      {aba === "categorias" && (
        <section className="panel p-6">
          <h2 className="text-sm font-semibold mb-4">Categorias de transações</h2>

          <div className="flex gap-2 mb-4">
            <input type="text" value={novaCategoria} onChange={function(e) { setNovaCategoria(e.target.value); }}
              onKeyDown={function(e) { if (e.key === "Enter") adicionarCategoria(); }}
              placeholder="Nome da nova categoria..."
              className="flex-1 rounded-lg border border-border bg-background px-3 py-2 text-sm" />
            <button type="button" onClick={adicionarCategoria}
              className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
              Adicionar
            </button>
          </div>

          <div className="divide-y divide-border rounded-xl border border-border">
            {categorias.length === 0 && (
              <div className="px-4 py-6 text-sm text-muted-foreground text-center">Nenhuma categoria cadastrada.</div>
            )}
            {categorias.map(function(c) { return (
              <div key={c.id} className="flex items-center justify-between px-4 py-3">
                <span className="text-sm">{c.nome}</span>
                <button type="button" onClick={function() { excluirCategoria(c.id); }}
                  className="rounded-lg px-3 py-1 text-xs font-medium text-red-600 hover:bg-red-50 transition-colors">
                  Excluir
                </button>
              </div>
            ); })}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">{categorias.length} categorias cadastradas</p>
        </section>
      )}

      {aba === "contas" && (
        <section className="panel p-6">
          <h2 className="text-sm font-semibold mb-4">Contas Bancárias</h2>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 mb-4">
            <input type="text" value={novaConta.banco} onChange={function(e) { setNovaConta({...novaConta, banco: e.target.value}); }}
              placeholder="Banco (ex: Bradesco)"
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
            <input type="text" value={novaConta.agencia} onChange={function(e) { setNovaConta({...novaConta, agencia: e.target.value}); }}
              placeholder="Agência (ex: 1234)"
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
            <input type="text" value={novaConta.conta} onChange={function(e) { setNovaConta({...novaConta, conta: e.target.value}); }}
              placeholder="Conta (ex: 12345-6)"
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
            <select value={novaConta.tipo} onChange={function(e) { setNovaConta({...novaConta, tipo: e.target.value}); }}
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm">
              <option value="corrente">Conta Corrente</option>
              <option value="poupanca">Poupança</option>
              <option value="salario">Conta Salário</option>
              <option value="investimento">Investimento</option>
            </select>
            <input type="text" value={novaConta.titular} onChange={function(e) { setNovaConta({...novaConta, titular: e.target.value}); }}
              placeholder="Titular (opcional)"
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
            <button type="button" onClick={adicionarConta}
              className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
              Adicionar Conta
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-muted-foreground">
                <tr className="border-b border-border">
                  <th className="py-2 font-medium">Banco</th>
                  <th className="py-2 font-medium">Agência</th>
                  <th className="py-2 font-medium">Conta</th>
                  <th className="py-2 font-medium">Tipo</th>
                  <th className="py-2 font-medium">Titular</th>
                  <th className="py-2 font-medium"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {contas.length === 0 && (
                  <tr><td colSpan={6} className="py-6 text-center text-muted-foreground">Nenhuma conta bancária cadastrada.</td></tr>
                )}
                {contas.map(function(c) { return (
                  <tr key={c.id}>
                    <td className="py-2.5">{c.banco}</td>
                    <td className="py-2.5">{c.agencia}</td>
                    <td className="py-2.5">{c.conta}</td>
                    <td className="py-2.5 capitalize">{c.tipo}</td>
                    <td className="py-2.5">{c.titular || "—"}</td>
                    <td className="py-2.5">
                      <button type="button" onClick={function() { excluirConta(c.id); }}
                        className="rounded-lg px-3 py-1 text-xs font-medium text-red-600 hover:bg-red-50 transition-colors">
                        Excluir
                      </button>
                    </td>
                  </tr>
                ); })}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">{contas.length} contas cadastradas</p>
        </section>
      )}
      {aba === "usuario" && (
        <section className="panel p-6">
          <h2 className="text-sm font-semibold mb-4">Alterar usuário e senha</h2>
          <div className="grid gap-3 sm:grid-cols-2 mb-4">
            <input type="text" value={novoNome} onChange={function(e) { setNovoNome(e.target.value); }} placeholder="Novo nome de usuário" className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
            <input type="password" value={novaSenha} onChange={function(e) { setNovaSenha(e.target.value); }} placeholder="Nova senha" className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
          </div>
          <button type="button" onClick={salvarUsuario} className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Salvar</button>
          {msgUsuario && <p className="mt-2 text-sm text-green-600">{msgUsuario}</p>}
        </section>
      )}
    </AppShell>
  );
}
