import { NavLink, Link } from "react-router-dom";
import { useEffect, useState, type ReactNode } from "react";

function useArmazenamento() {
  const [ok, setOk] = useState(true);
  useEffect(() => {
    try { window.localStorage.setItem("renda:teste", "1"); window.localStorage.removeItem("renda:teste"); setOk(true); } catch { setOk(false); }
  }, []);
  return ok;
}

const NAV = [
  { to: "/", label: "Painel" },
  { to: "/transacoes", label: "Transações" },
  { to: "/relatorios", label: "Relatórios" },
  { to: "/empresa", label: "Empresa" },
  { to: "/configuracoes", label: "Configurações" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const armazenamentoOk = useArmazenamento();
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-3 px-4 py-3 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-xl bg-primary font-display text-base font-bold text-primary-foreground">R</span>
            <span className="font-display text-base font-semibold">Renda</span>
          </Link>
          <nav className="flex flex-wrap items-center gap-1 text-sm">
            {NAV.map((item) => (
              <NavLink key={item.to} to={item.to} end={item.to === "/"}
                className={({ isActive }) => `rounded-lg px-3 py-1.5 transition-colors hover:bg-secondary hover:text-foreground ${isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                {item.label}
              </NavLink>
            ))}
          </nav>
          <div className="ml-auto hidden items-center gap-3 sm:flex">
          {(() => { try { var u = JSON.parse(localStorage.getItem("renda:usuario") || "{}"); return u.nome ? (<span className="text-sm font-medium">{"Olá, " + u.nome + "!"}</span>) : null; } catch(e) { return null; } })()}
          <button type="button" onClick={function() { localStorage.removeItem("renda:usuario"); window.location.reload(); }} className="rounded-lg border border-border px-3 py-1.5 text-xs text-muted-foreground hover:bg-secondary transition-colors">Sair</button>
        </div>
        <div className={`ml-0 hidden items-center gap-2 rounded-full border px-3 py-1.5 text-xs sm:flex ${armazenamentoOk ? "border-border text-muted-foreground" : "border-negative text-negative"}`}>
            <span className={`size-1.5 rounded-full ${armazenamentoOk ? "bg-positive" : "bg-negative"}`} />
            {armazenamentoOk ? "Dados salvos no banco SQLite" : "Erro de conexão com o banco"}
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">{children}</main>
      <footer className="mx-auto max-w-6xl border-t border-border px-4 py-6 text-xs text-muted-foreground sm:px-6">
        Renda · controle financeiro pessoal · valores em reais (R$) · banco SQLite local
      </footer>
    </div>
  );
}

export function PageHeader({ titulo, descricao, acao }: { titulo: string; descricao: string; acao?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">{titulo}</h1>
        <p className="mt-1.5 max-w-xl text-sm text-muted-foreground">{descricao}</p>
      </div>
      {acao}
    </div>
  );
}
